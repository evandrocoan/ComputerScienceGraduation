function y = f(x)
	y = cos(x);
end
