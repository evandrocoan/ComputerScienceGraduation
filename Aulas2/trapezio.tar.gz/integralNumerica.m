clear
clc
format long

a = 1
b = 6

n = 16364

Tn = fTrapezio( n, a, b )

_I = log( 1 + b ) - log( 1 + a )

T2 = fTrapezio( 2 * n, a, b )
erroExato = abs( Tn - _I )
erroExatoEstimado = abs( Tn - T2 )
