function y = df(x)

y = log(x) .+ 1;

end
