function y=funcaoTempo(x, N, C);
	y=(x(1) + x(2) * N^2 ) / ( 1 + x(3) * C );
end
