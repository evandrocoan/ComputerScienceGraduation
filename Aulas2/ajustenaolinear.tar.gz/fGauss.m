function x = fGauss(n, A)

	A = fEscalona(n, A);

	x = fRetroSubs(n, A);

end
