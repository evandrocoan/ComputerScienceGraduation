function y = g( x )
	y = 1 / (1 + x);
end
