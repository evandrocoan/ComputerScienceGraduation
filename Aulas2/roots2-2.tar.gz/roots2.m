function x = roots2( a )
	erroMax = 1.e-15;

	%cálculo do grau do polinomio, size retorna as dimensões da matriz, e max pega seu maior valor
	n = max( size( a ) ) - 1 ;
	xi = fLocalizaPoli( n, a );
	nRaizes = n;
	%ir -> indica qual raíz se está trabalhando
	for ir = 1 : nRaizes 
		% x vetor das raízes encontradas
		[ x(ir) erro cont ] = fNRPoli( n, a, xi(ir), erroMax)
		%reduzir o grau do polinômio ( Pn(x) / (x - x(ir) ) )
		a = fDivBrio( n, a, x(ir) ); 
		printf( "\nResto da divisão: %.20f\n", a(n + 1) );
		n--;
	end
	
end
