function xi = fLocalizaPoli( n, a)
	alpha = modMax( n, a );

	%construção do vetor inicial para cálculo das raízes, menores que alpha, que indica o limite máximo para uma raíz
	aux = sqrt( alpha ) * .5;
	xi(1:n) = complex( aux, aux );
end
