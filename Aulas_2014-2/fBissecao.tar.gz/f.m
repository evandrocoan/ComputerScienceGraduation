function y = f(x)

y = x .* log(x) .- 1;

end
