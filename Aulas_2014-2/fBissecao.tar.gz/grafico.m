clc
clear
format long

%dominio da função
A = realmin;
B = 10;

%cria um vetor de 3000 posições com variação de 0.001
x = 0.001 : 0.1 : 3;

%cria outro vetor de 3000 valores
y = f(x);

h = 0.1;
erroMaximo = 1.e-6;

%indice da raiz
ir = 0;
a = A;
b = a + h;
while b < B-h
	%
	if( f(a) * f(b) < 0 )
		ir = ir + 1		
		xInicio(ir) = a;
		xFinal(ir) = b;		
		[ erro raiz(ir) ] = fBissecao( xInicio(ir), xFinal(ir), erroMaximo)
	end 
	a = b;
	b = a + h;
	%
end
xInicio
xFinal
%desenha os pontos dos vetores x e y
plot( x, y )
grid on;
