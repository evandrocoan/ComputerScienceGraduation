%clc
clear
format long

a = [ 7.3  5.4  complex( 0, -1 )   -2 -3.2  7 ]; % coeficientes do polinômio
b = [ 1 1 1 1 1 1 ];
c = [ 1 -3  3  -1 ];%(x-1)³=0 -> raizes={1 1 1} x=1 com M=3 (multiplicidade)
d = [ 1 -5.4 12.15 -14.58 9.8415 -3.54294 0.531441];

raiz = roots2( d )
roots(d)
