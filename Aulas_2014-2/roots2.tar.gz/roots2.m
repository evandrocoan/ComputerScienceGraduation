function raiz = roots2( a )
	erroMax = 1.e-15;

	%cálculo do grau do polinomio
	n = max(size(a)) - 1 
	alpha = modMax( n, a )

	%construção do vetor inicial para cálculo das raízes, menores que alpha, que indica o limite máximo para uma raíz
	aux = sqrt( alpha );
	xi(1:n) = complex( aux, aux )

	% indica qual raíz se está trabalhando
	ir = 1; 
	% x vetor das raízes encontradas
	[ x(ir) erro cont ] = fNRPoli( n, a, xi(ir), erroMax) 
	
end
