% n, a -> conjunto de coeficientes do polinomio
% xi -> ponto inicial para o cálculo
function [ x erro cont ] = fNRPoli( n, a, xi, erroMax) 
	erro = erroMax + 1;
	cont = 0;
	while ( ( erro > erroMax ) & ( cont < 100 ) )
	cont = cont + 1
%inicio do núcleo do método (nunca mexa!)
		%fPn -> função calculo o valor numérico de Pn( x = xi ), 
		% para qualquer polinômio de entrada (n e a)
	   dX = - fPn( n, a, xi ) / df(xi)
      x = xi + dX;
		% erro = abs(dX);
      xi = x;
%fim do núcleo do método
		%cálculo do erro
		erro = abs( f(x) ); 
	end

end
