clc
clear

a = [ 7.3 5.4 complex( 0, -1 ) -2 -3.2 7 ] % coeficientes do polinômio

raiz = roots2( a )
